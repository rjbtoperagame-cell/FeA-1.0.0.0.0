import { SkillRank, SkillNode, XPConfig, getSkillXpCost } from '../types';

export const RANK_ORDER: SkillRank[] = ['D', 'C', 'B', 'A', 'S', 'SS (Suprema)'];

export function cleanRank(rankStr: string | undefined): SkillRank {
  if (!rankStr) return 'D';
  if (rankStr.includes('SS')) return 'SS (Suprema)';
  if (rankStr.includes('S')) return 'S';
  if (rankStr.includes('A')) return 'A';
  if (rankStr.includes('B')) return 'B';
  if (rankStr.includes('C')) return 'C';
  return 'D';
}

export function isRankAtLeast(rankStr: string | undefined, target: SkillRank): boolean {
  const current = cleanRank(rankStr);
  const targetClean = cleanRank(target);

  const ranks: SkillRank[] = ['D', 'C', 'B', 'A', 'S', 'SS (Suprema)'];
  const curIdx = ranks.indexOf(current);
  const targetIdx = ranks.indexOf(targetClean);

  if (curIdx === -1 || targetIdx === -1) return false;
  return curIdx >= targetIdx;
}

export function getNextRank(currentRankStr: string | undefined): SkillRank | null {
  const current = cleanRank(currentRankStr);
  const ranks: SkillRank[] = ['D', 'C', 'B', 'A', 'S', 'SS (Suprema)'];
  const idx = ranks.indexOf(current);
  if (idx === -1 || idx >= ranks.length - 1) return null;
  return ranks[idx + 1];
}

export function getRankCost(tier: number, rank: SkillRank, xpConfig?: XPConfig): number {
  let rankKey = 'D';
  if (rank.includes('SS')) rankKey = 'SS';
  else if (rank.includes('S')) rankKey = 'S';
  else if (rank.includes('A')) rankKey = 'A';
  else if (rank.includes('B')) rankKey = 'B';
  else if (rank.includes('C')) rankKey = 'C';

  const key = `${tier}_${rankKey}`;
  if (xpConfig?.tierRankXpCosts && xpConfig.tierRankXpCosts[key] !== undefined) {
    return xpConfig.tierRankXpCosts[key];
  }
  return getSkillXpCost({ tier, rank }, xpConfig);
}

export function getSkillNextUpgradeCost(
  tier: number,
  currentRankStr: string | undefined,
  xpConfig?: XPConfig
): { nextRank: SkillRank; cost: number } | null {
  const next = getNextRank(currentRankStr);
  if (!next) return null;
  const cost = getRankCost(tier, next, xpConfig);
  return { nextRank: next, cost };
}

export function getSkillTotalSpent(
  tier: number,
  currentRankStr: string | undefined,
  xpConfig?: XPConfig
): number {
  const current = cleanRank(currentRankStr);
  const ranks: SkillRank[] = ['D', 'C', 'B', 'A', 'S', 'SS (Suprema)'];
  const curIdx = ranks.indexOf(current);
  if (curIdx === -1) return getRankCost(tier, 'D', xpConfig);

  let sum = 0;
  for (let i = 0; i <= curIdx; i++) {
    sum += getRankCost(tier, ranks[i], xpConfig);
  }
  return sum;
}

export function checkTierUnlocked(
  tier: number,
  unlockedSkillIds: string[],
  userSkillRanks: Record<string, SkillRank>,
  allSkillsMap: Record<string, SkillNode>
): { unlocked: boolean; reason?: string } {
  if (tier <= 1) return { unlocked: true };

  const prevTierUnlockedSkills = unlockedSkillIds
    .map((id) => allSkillsMap[id])
    .filter((sk) => sk && sk.tier === tier - 1);

  if (prevTierUnlockedSkills.length === 0) {
    return {
      unlocked: false,
      reason: `Bloqueado: Requer pelo menos 1 habilidade do Tier ${tier - 1} desbloqueada e no Rank B ou superior.`,
    };
  }

  const hasRankB = prevTierUnlockedSkills.some((sk) => {
    const rank = userSkillRanks[sk.id] || 'D';
    return isRankAtLeast(rank, 'B');
  });

  if (!hasRankB) {
    return {
      unlocked: false,
      reason: `Bloqueado: Nenhuma habilidade do Tier ${tier - 1} está no Rank B ou superior. Evolua o Rank de uma habilidade do Tier ${tier - 1} para B para liberar este Tier!`,
    };
  }

  return { unlocked: true };
}

export function getCombatStatCost(statKey: string, xpConfig?: XPConfig): number {
  const defaults: Record<string, number> = {
    pvs: 20,
    pms: 20,
    ataque: 50,
    atqEspecial: 50,
    defesa: 50,
    defEspecial: 50,
    critico: 80,
    velAtq: 50,
    velMov: 50,
    velEspecial: 50,
  };

  if (xpConfig?.combatStatCosts && (xpConfig.combatStatCosts as any)[statKey] !== undefined) {
    return (xpConfig.combatStatCosts as any)[statKey];
  }

  return defaults[statKey] || 50;
}
