-- SQL Schema 100% idempotente para Supabase
-- Pode executar quantas vezes quiser sem dar erro de objeto duplicado!

-- 1. Criar tabela 'users' se não existir
CREATE TABLE IF NOT EXISTS public.users (
  username TEXT PRIMARY KEY,
  password TEXT DEFAULT '',
  role TEXT DEFAULT 'user',
  character_name TEXT DEFAULT 'Guardião',
  animal_id TEXT DEFAULT 'leao',
  xp_total NUMERIC DEFAULT 1000,
  sheet_data JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Criar tabela 'system_config' se não existir
CREATE TABLE IF NOT EXISTS public.system_config (
  id TEXT PRIMARY KEY,
  data JSONB DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Habilitar Row Level Security (RLS)
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_config ENABLE ROW LEVEL SECURITY;

-- Remover políticas antigas se existirem para evitar erros de duplicidade
DROP POLICY IF EXISTS "Allow public read access to users" ON public.users;
DROP POLICY IF EXISTS "Allow public insert/update to users" ON public.users;
DROP POLICY IF EXISTS "Allow public read access to system_config" ON public.system_config;
DROP POLICY IF EXISTS "Allow public insert/update to system_config" ON public.system_config;

-- Criar políticas de acesso público
CREATE POLICY "Allow public read access to users" ON public.users FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update to users" ON public.users FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Allow public read access to system_config" ON public.system_config FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update to system_config" ON public.system_config FOR ALL USING (true) WITH CHECK (true);

-- 4. Adicionar tabelas ao Supabase Realtime com tratamento de erro se já existirem
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.users;
  EXCEPTION
    WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.system_config;
  EXCEPTION
    WHEN duplicate_object THEN NULL;
  END;
END $$;
